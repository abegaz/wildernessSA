package com.wildertest.controller;

import java.sql.Connection;
import java.sql.PreparedStatement;

import application.WilderTestDBConfig;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class AdminGUIController {

	@FXML private Button createUserButton, userView;
	@FXML private TextField userNameTextField, passwordTextField;
	
	private Stage stage;
	private AnchorPane root;
	private Scene scene;
	private Connection conn;
	
	@FXML
	public void createUser(ActionEvent event) throws Exception{
		//may want to use a prepared statement
		conn = WilderTestDBConfig.getConnection();
		String createUser = "INSERT INTO USERS (userName, password) VALUES (" + userNameTextField.getText() + passwordTextField.getText() + ")";
		PreparedStatement updateUsers = conn.prepareStatement(createUser);
		updateUsers.execute(createUser);
		//You need to have this in a try/catch, and close the result set, statement, and connection (in that order).
		
	}
	
	@FXML
	public void userView(ActionEvent event) throws Exception{
		 stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
         root = FXMLLoader.load(getClass().getResource("../view/ReportDetailView.fxml"));
         scene = new Scene(root);
         stage.setScene(scene);
	}

}
