package com.wildertest.controller;

import application.WilderTestDBConfig;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class LoginController {
    @FXML private Label loginTitleLabel;
    @FXML private TextField usernameTextField, passwordTextField;
    @FXML private Button loginButton;

    private Stage stage;
    private AnchorPane root;
    private Scene scene;
    private Connection conn;
    private static String permission = "";
    private static String userID = "";

    public void login(ActionEvent event) throws Exception {
        if(checkHashPass() == true) {

            stage = (Stage) ((Button) event.getSource()).getScene().getWindow();

            root = FXMLLoader.load(getClass().getResource("../view/ReportDetailView.fxml"));
            scene = new Scene(root);
            stage.setScene(scene);
        } else System.out.println("login failed");

    }
    private static int hashPass(String password) {
        int hash = 7;
        for (int i = 0; i < password.length(); i++) {
            hash = hash*31 + password.charAt(i);
        }
        return hash;
    }

    public boolean checkHashPass(){
        String permission ="";

        try {
            permission = getPermission(usernameTextField.getText(), String.valueOf(hashPass(passwordTextField.getText())));
            System.out.println("The permission level is"+ permission);

            conn = WilderTestDBConfig.getConnection();

        } catch (Exception e) {

        }
        if (permission.equals("1") || permission.equals("2")) {
            return true;
        }
            else return false;
    }
    /*
SELECT users.privilege
FROM users
WHERE users.password = 1449706402
AND
users.username = 'Admin'
GROUP BY users.userID;

 */
    public static String getPermission(String username, String password) {

        try {
            Connection connection = WilderTestDBConfig.getConnection();
            PreparedStatement statement = connection.prepareStatement(
                    "SELECT users.privilege, users.userID FROM users Where users.password ="+password+
            " AND users.username ="+"'"+username+"'"+" GROUP BY users.userID;");
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                permission = String.valueOf(resultSet.getInt("privilege"));
                userID = String.valueOf(resultSet.getInt("userID"));
            }
            connection.close();
        } catch (Exception exception) {
            exception.printStackTrace();
        }
        System.out.println("the userID is: "+userID);
        System.out.println("privilege @getPermission is"+ permission);
        return permission;
    }

}

