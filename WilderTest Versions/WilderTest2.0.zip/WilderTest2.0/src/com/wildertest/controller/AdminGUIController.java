package com.wildertest.controller;

import java.sql.Connection;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class AdminGUIController {
	@FXML private Button createUserButton, userView;
	@FXML private TextField userNameTextField, passwordTextField;
	
	  private Stage stage;
	   private AnchorPane root;
	   private Scene scene;
	   private Connection conn;
	
	public String createUser(ActionEvent event) throws Exception{
		//may want to use a prepared statement
		String createUser = "INSERT INTO USERS (userName, password) VALUES (" + userNameTextField.getText() + passwordTextField.getText() + ")";
		return createUser;
		
	}
	public void userView(ActionEvent event) throws Exception{
		 stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
         root = FXMLLoader.load(getClass().getResource("../view/ReportDetailView.fxml"));
         scene = new Scene(root);
         stage.setScene(scene);
	}

}
