package com.wildertest.model;

public class User {

}
