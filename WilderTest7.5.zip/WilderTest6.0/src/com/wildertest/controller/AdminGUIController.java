package com.wildertest.controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;

import application.WilderTestDBConfig;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class AdminGUIController /*extends LoginController*/ {

	@FXML private Button createUserButton, userView;
	@FXML private TextField userNameTextField, passwordTextField;
	
	private Stage stage;
	private AnchorPane root;
	private Scene scene;
	private Connection conn;
	
	@FXML
	public void createUser(ActionEvent event) throws Exception{
		//may want to use a prepared statement
		boolean itWorked = false;
		
		PreparedStatement updateUsers = null;
		String createUser = "INSERT INTO users (privilege, username, password) VALUES ( " + "'1', " + "'" + userNameTextField.getText() + "', " + "'" + LoginController.hashPass(passwordTextField.getText())+ "'" + ");";
		try
		{
		conn = WilderTestDBConfig.getConnection();
		updateUsers = conn.prepareStatement(createUser);
		updateUsers.executeUpdate(createUser);
		itWorked = true;
		//You need to have this in a try/catch, and close the result set, statement, and connection (in that order).
		}
		catch(Exception e) {
			itWorked = false;
			System.out.println("Insertion failed.");
        	e.printStackTrace();
		}
		 finally {
	          	try {updateUsers.close(); } catch (Exception e) {}
	            try { conn.close(); } catch (Exception e) {}
		 }
		if(itWorked == true)
		{
			//String newUserQuery = "select * from users where userID = (select max(userID) from users)";
			//checkUsersTable();
			//Statement statement = conn.createStatement();
			//statement.executeQuery(newUserQuery);
			//System.out.println(statement);
		}
	}
	
	@FXML
	public void userView(ActionEvent event) throws Exception{
		 stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
         root = FXMLLoader.load(getClass().getResource("../view/ReportDetailView.fxml"));
         scene = new Scene(root);
         stage.setScene(scene);
	}

}
