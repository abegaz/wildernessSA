package com.winderness.model;

public class Forcast {
}
